/**
 * Status Effects Index
 *
 * Exports status effect hooks:
 * - Status ticks
 *
 * Location: apps/mobile/src/effects/chat/status/index.ts
 */

export * from './use-status-ticks'
