/**
 * UI Effects Index
 *
 * Exports UI effect hooks:
 * - Scroll FAB magnetic
 *
 * Location: apps/mobile/src/effects/chat/ui/index.ts
 */

export * from './use-scroll-fab-magnetic'
