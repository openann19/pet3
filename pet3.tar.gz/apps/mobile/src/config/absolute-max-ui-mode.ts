/**
 * ABSOLUTE_MAX_UI_MODE - Global ultra-premium UI configuration (Mobile)
 *
 * This configuration enforces premium animation, theme, and smoothness profile
 * across all visual components including GPU performance, blur layering, haptics,
 * and emotional color logic.
 *
 * Location: apps/mobile/src/config/absolute-max-ui-mode.ts
 */

export type HapticStrength = 'light' | 'medium' | 'strong';

export type TapFeedback = 'spring' | 'scale' | 'none';

export type ThemeVariant = 'glass' | 'neon' | 'dark' | 'vibrant';

export interface SpringPhysics {
  damping: number;
  stiffness: number;
  mass: number;
}

export interface VisualConfig {
  enableBlur: boolean;
  enableGlow: boolean;
  enableShadows: boolean;
  enableShimmer: boolean;
  enable3DTilt: boolean;
  backdropSaturation: number;
  maxElevation: number;
  borderRadius: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl';
  highContrastText: boolean;
}

export interface AnimationConfig {
  enableReanimated: boolean;
  smoothEntry: boolean;
  tapFeedback: TapFeedback;
  motionBlur: boolean;
  springPhysics: SpringPhysics;
  showParticles: boolean;
  showTrails: boolean;
  motionFPS: number;
}

export interface PerformanceConfig {
  runOnUIThread: boolean;
  skipReactRender: boolean;
  useSkiaWhereAvailable: boolean;
  flatListOptimized: boolean;
  layoutAwareAnimations: boolean;
}

export interface FeedbackConfig {
  haptics: boolean;
  hapticStrength: HapticStrength;
  sound: boolean;
  showTooltips: boolean;
}

export interface ThemeConfig {
  adaptiveMood: boolean;
  gradientIntensity: number;
  themeVariants: ThemeVariant[];
  avatarGlow: boolean;
  dynamicBackground: boolean;
}

export interface DebugConfig {
  logFrameDrops: boolean;
  traceSharedValues: boolean;
}

export interface AbsoluteMaxUIModeConfig {
  visual: VisualConfig;
  animation: AnimationConfig;
  performance: PerformanceConfig;
  feedback: FeedbackConfig;
  theme: ThemeConfig;
  debug: DebugConfig;
}

/**
 * ABSOLUTE_MAX_UI_MODE - Global ultra-premium UI configuration
 *
 * Apply globally to all visual components:
 * - Chat bubbles (BubbleWrapper)
 * - Buttons, dialogs, menus
 * - Reactions, emoji trail
 * - Typing shimmer
 * - Delete animations
 * - Particle effects
 * - Presence avatars
 * - Layout transitions
 * - Theming engine
 */
export const ABSOLUTE_MAX_UI_MODE: AbsoluteMaxUIModeConfig = {
  visual: {
    enableBlur: true,
    enableGlow: true,
    enableShadows: true,
    enableShimmer: true,
    enable3DTilt: true,
    backdropSaturation: 1.5,
    maxElevation: 24,
    borderRadius: '2xl',
    highContrastText: true,
  },
  animation: {
    enableReanimated: true,
    smoothEntry: true,
    tapFeedback: 'spring',
    motionBlur: true,
    springPhysics: {
      damping: 15,
      stiffness: 250,
      mass: 0.9,
    },
    showParticles: true,
    showTrails: true,
    motionFPS: 60,
  },
  performance: {
    runOnUIThread: true,
    skipReactRender: true,
    useSkiaWhereAvailable: true,
    flatListOptimized: true,
    layoutAwareAnimations: true,
  },
  feedback: {
    haptics: true,
    hapticStrength: 'strong',
    sound: true,
    showTooltips: true,
  },
  theme: {
    adaptiveMood: true,
    gradientIntensity: 1.4,
    themeVariants: ['glass', 'neon', 'dark', 'vibrant'],
    avatarGlow: true,
    dynamicBackground: true,
  },
  debug: {
    logFrameDrops: false,
    traceSharedValues: false,
  },
} as const;
