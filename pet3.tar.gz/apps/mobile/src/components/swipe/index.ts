/**
 * Index file for swipe components
 * Location: src/components/swipe/index.ts
 */

export { MatchCelebration } from './MatchCelebration'
export { SwipeCard } from './SwipeCard'
export { SwipeCardStack } from './SwipeCardStack'
