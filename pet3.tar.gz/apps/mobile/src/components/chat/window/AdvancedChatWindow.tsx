export { default } from '../AdvancedChatWindow'
export type { AdvancedChatWindowProps } from '../AdvancedChatWindow'
